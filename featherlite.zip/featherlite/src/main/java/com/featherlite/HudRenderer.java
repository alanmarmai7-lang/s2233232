package com.featherlite;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public class HudRenderer implements HudRenderCallback {
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFAAAAAA;
    private static final int BG = 0x90000000;
    private static final int BG_PRESSED = 0xB0FFFFFF;
    private static final int KEY_SIZE = 20;

    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean leftWasDown = false;
    private boolean rightWasDown = false;

    @Override
    public void onHudRender(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        pollClicks(mc);

        if (!FeatherLiteClient.hudVisible || mc.getDebugHud().shouldShowDebugHud()) return;

        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        drawInfoPanel(ctx, mc, tr);
        drawKeystrokes(ctx, mc, tr, 6, sh / 2 - 30);
        drawArmor(ctx, mc, tr, sw - 6, sh / 2 - 40);
    }

    // ---------------------------------------------------------------- CPS

    private void pollClicks(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();
        boolean inGame = mc.currentScreen == null;

        boolean left = inGame && GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = inGame && GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();

        if (left && !leftWasDown) leftClicks.addLast(now);
        if (right && !rightWasDown) rightClicks.addLast(now);
        leftWasDown = left;
        rightWasDown = right;

        prune(leftClicks, now);
        prune(rightClicks, now);
    }

    private static void prune(Deque<Long> clicks, long now) {
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.removeFirst();
    }

    // ---------------------------------------------------------------- Info panel

    private void drawInfoPanel(DrawContext ctx, MinecraftClient mc, TextRenderer tr) {
        int x = 6, y = 6;
        String[] lines = {
                "FPS: " + mc.getCurrentFps(),
                "CPS: " + leftClicks.size() + " | " + rightClicks.size(),
                String.format("XYZ: %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()),
                "Facing: " + mc.player.getHorizontalFacing().asString().toUpperCase(),
                "Sprint: " + (FeatherLiteClient.sprintToggled ? "Toggled" : "Hold")
        };

        int width = 0;
        for (String s : lines) width = Math.max(width, tr.getWidth(s));
        ctx.fill(x - 3, y - 3, x + width + 3, y + lines.length * 11 + 1, BG);

        for (int i = 0; i < lines.length; i++) {
            ctx.drawTextWithShadow(tr, lines[i], x, y + i * 11, WHITE);
        }
    }

    // ---------------------------------------------------------------- Keystrokes

    private void drawKeystrokes(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int x, int y) {
        int gap = 2;
        int step = KEY_SIZE + gap;

        drawKey(ctx, tr, "W", mc.options.forwardKey, x + step, y, KEY_SIZE, KEY_SIZE);
        drawKey(ctx, tr, "A", mc.options.leftKey, x, y + step, KEY_SIZE, KEY_SIZE);
        drawKey(ctx, tr, "S", mc.options.backKey, x + step, y + step, KEY_SIZE, KEY_SIZE);
        drawKey(ctx, tr, "D", mc.options.rightKey, x + step * 2, y + step, KEY_SIZE, KEY_SIZE);

        int mouseY = y + step * 2;
        int halfW = (KEY_SIZE * 3 + gap * 2 - gap) / 2;
        drawBox(ctx, tr, "LMB " + leftClicks.size(), leftWasDown, x, mouseY, halfW, KEY_SIZE);
        drawBox(ctx, tr, "RMB " + rightClicks.size(), rightWasDown, x + halfW + gap, mouseY, halfW, KEY_SIZE);

        drawKey(ctx, tr, "SPACE", mc.options.jumpKey, x, mouseY + step, KEY_SIZE * 3 + gap * 2, 14);
    }

    private void drawKey(DrawContext ctx, TextRenderer tr, String label, KeyBinding key,
                         int x, int y, int w, int h) {
        drawBox(ctx, tr, label, key.isPressed(), x, y, w, h);
    }

    private void drawBox(DrawContext ctx, TextRenderer tr, String label, boolean pressed,
                         int x, int y, int w, int h) {
        ctx.fill(x, y, x + w, y + h, pressed ? BG_PRESSED : BG);
        int color = pressed ? 0xFF000000 : WHITE;
        int tx = x + (w - tr.getWidth(label)) / 2;
        int ty = y + (h - 8) / 2;
        ctx.drawText(tr, label, tx, ty, color, false);
    }

    // ---------------------------------------------------------------- Armor / item status

    private void drawArmor(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int right, int y) {
        EquipmentSlot[] slots = {
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
                EquipmentSlot.FEET, EquipmentSlot.MAINHAND
        };

        int row = 0;
        for (EquipmentSlot slot : slots) {
            ItemStack stack = mc.player.getEquippedStack(slot);
            if (stack.isEmpty()) continue;

            int rowY = y + row * 18;
            String text = stack.isDamageable()
                    ? String.valueOf(stack.getMaxDamage() - stack.getDamage())
                    : (stack.getCount() > 1 ? "x" + stack.getCount() : "");

            int textW = tr.getWidth(text);
            int iconX = right - 16;

            ctx.drawItem(stack, iconX, rowY);
            if (!text.isEmpty()) {
                int color = stack.isDamageable() ? durabilityColor(stack) : GRAY;
                ctx.drawTextWithShadow(tr, text, iconX - textW - 3, rowY + 4, color);
            }
            row++;
        }
    }

    private static int durabilityColor(ItemStack stack) {
        float frac = 1f - (float) stack.getDamage() / stack.getMaxDamage();
        if (frac > 0.6f) return 0xFF55FF55;
        if (frac > 0.3f) return 0xFFFFFF55;
        return 0xFFFF5555;
    }
}
